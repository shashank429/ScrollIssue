﻿using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Runtime.CompilerServices;


namespace ScrollIssue_MAUI
{
    public partial class MainPage : ContentPage, INotifyPropertyChanged
    {
        private const int PageSize = 20;
        private int currentPage = 0;
        private readonly SemaphoreSlim _loadingSemaphore = new SemaphoreSlim(1, 1);


        private bool isNextPageLoading;
        public bool IsNextPageLoading
        {
            get { return isNextPageLoading; }
            set { SetProperty(ref isNextPageLoading, value); }
        }

        private ObservableRangeCollection<StopItems> visibleStopItems = new();
        public ObservableRangeCollection<StopItems> VisibleStopItems
        {
            get => visibleStopItems;
            set => SetProperty(ref visibleStopItems, value);
        }

        //Additional: You can change the stopItemsList to List<T> for better efficiency also
        private List<StopItems> stopItemsList = new();
        public List<StopItems> StopItemsList
        {
            get => stopItemsList;
            set => SetProperty(ref stopItemsList, value);
        }

        public MainPage()
        {
            InitializeComponent();

            BindingContext = this;

           
            Init();
        }

        private async Task Init()
        {
            var stopItems = Newtonsoft.Json.JsonConvert.DeserializeObject<List<StopItems>>(AppResources.StaticResponse);

            StopItemsList = new List<StopItems>(stopItems);

            await LoadNextPageAsync();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = "")
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        protected bool SetProperty<T>(ref T backingStore, T value, [CallerMemberName] string propertyName = "")
        {
            if (EqualityComparer<T>.Default.Equals(backingStore, value))
                return false;

            backingStore = value;
            OnPropertyChanged(propertyName);
            return true;
        }

        public async Task LoadNextPageAsync()
        {
            if (StopItemsList == null || !StopItemsList.Any())
                return;

            if (!await _loadingSemaphore.WaitAsync(0))
                return;

            if (IsNextPageLoading)
                return;

            IsNextPageLoading = true;

            try
            {

                var nextItems = await Task.Run(() =>
                {
                    return StopItemsList
                        .Skip(currentPage * PageSize)
                        .Take(PageSize)
                        .ToList();
                });

                if (nextItems.Count == 0)
                    return;

                // Add items to the UI-bound collection in a batch on the main thread
                const int batchSize = 3;
                for (int i = 0; i < nextItems.Count; i += batchSize)
                {
                    var batch = nextItems.Skip(i).Take(batchSize).ToList();
                    await MainThread.InvokeOnMainThreadAsync(() =>
                    {
                        VisibleStopItems.AddRange(batch);
                    });

                    // Small delay between batches if needed
                    if (i + batchSize < nextItems.Count)
                        await Task.Delay(10).ConfigureAwait(false);
                }

                currentPage++;
            }
            finally
            {
                IsNextPageLoading = false;
                _loadingSemaphore.Release();
            }
        }

        private async void CollectionView_RemainingItemsThresholdReached(object sender, EventArgs e)
        {
            if (!IsNextPageLoading)
            {
                await LoadNextPageAsync();
            }
        }
    }

    public class ObservableRangeCollection<T> : ObservableCollection<T>
    {
        public void AddRange(IEnumerable<T> collection)
        {
            if (collection == null)
                return;

            var items = collection as List<T> ?? collection.ToList();
            if (items.Count == 0)
                return;

            var startIndex = Count;

            foreach (var item in items)
            {
                Items.Add(item);
            }
            if (Items == null)
                return;
            // Importants: Add following parameters to render only the part that new items add only
            // 1. Collection change notification
            OnCollectionChanged(new NotifyCollectionChangedEventArgs(
                NotifyCollectionChangedAction.Add,
                (IList)items,
                startIndex));

            // Add Other notifications
            // 2. Count property notification
            OnPropertyChanged(new PropertyChangedEventArgs(nameof(Count)));

        }
    }
}
