﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScrollIssue_MAUI
{
    public class StopItems
    {

        public bool? IsLoaded { get; set; }

        public string ItemDescription { get; set; }

        public string SerialNumber { get; set; }

        public string ItemCode { get; set; }

        public string Task { get; set; }

        public bool IsPickup { get; set; }

        public string ClientOrderNumber { get; set; }

        public string ClientCode { get; set; }

        public string ImageUrl { get; set; }

        public string ThumbnailUrl { get; set; }

        public int StopNumber { get; set; }

        public string ConsigneeName { get; set; }

        public string ClientName { get; set; }

        public int NoOfImagesUploaded { get; set; }

        public string ShipmentNumber { get; set; }

        public string LoadedScanType { get; set; }

        public string ItemStatus { get; set; }
        public string StopStatus { get; set; }

        public string DamageReason { get; set; }

        public bool IsPicturesMandatory { get; set; }

        public int MinimumImagesRequired { get; set; }

        public string PictureStatus { get; set; }

    }

}
