﻿using AndroidX.Lifecycle;
using Newtonsoft.Json;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;


namespace ScrollIssue_MAUI
{
    public partial class MainPage : ContentPage, INotifyPropertyChanged
    {
        private const int PageSize = 10;
        private int currentPage = 0;

        private bool isNextPageLoading;
        public bool IsNextPageLoading
        {
            get { return isNextPageLoading; }
            set { SetProperty(ref isNextPageLoading, value); }
        }

        private ObservableCollection<StopItems> visibleStopItems = new();
        public ObservableCollection<StopItems> VisibleStopItems
        {
            get => visibleStopItems;
            set => SetProperty(ref visibleStopItems, value);
        }

        private ObservableCollection<StopItems> stopItemsList = new();
        public ObservableCollection<StopItems> StopItemsList
        {
            get => stopItemsList;
            set => SetProperty(ref stopItemsList, value);
        }

        public MainPage()
        {
            InitializeComponent();

            BindingContext = this;

           
            Init();
        }

        private async Task Init()
        {
            var stopItems = Newtonsoft.Json.JsonConvert.DeserializeObject<List<StopItems>>(AppResources.StaticResponse);

            StopItemsList = new ObservableCollection<StopItems>(stopItems);

            await LoadNextPageAsync();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = "")
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        protected bool SetProperty<T>(ref T backingStore, T value, [CallerMemberName] string propertyName = "")
        {
            if (EqualityComparer<T>.Default.Equals(backingStore, value))
                return false;

            backingStore = value;
            OnPropertyChanged(propertyName);
            return true;
        }

        public async Task LoadNextPageAsync()
        {
            if (StopItemsList == null || !StopItemsList.Any())
                return;

            if (IsNextPageLoading)
                return;

            IsNextPageLoading = true;

            try
            {
                // Optional: reduce this or remove completely if not needed
                await Task.Delay(20);

                var nextItems = StopItemsList
                    .Skip(currentPage * PageSize)
                    .Take(PageSize)
                    .ToList();

                if (nextItems.Count == 0)
                    return;

                // Add items to the UI-bound collection in a batch on the main thread
                await MainThread.InvokeOnMainThreadAsync(() =>
                {
                    foreach (var item in nextItems)
                    {
                        VisibleStopItems.Add(item);
                    }
                });

                currentPage++;
            }
            finally
            {
                IsNextPageLoading = false;
            }
        }

        private async void childList_Scrolled(object sender, ScrolledEventArgs e)
        {
            try
            {
                var scrollView = sender as ScrollView;

                double scrollingSpace = scrollView.ContentSize.Height - scrollView.Height;
                double buffer = 40;

                bool isNearBottom = scrollingSpace <= e.ScrollY + buffer;

                if (isNearBottom)
                {
                    if (!IsNextPageLoading)
                    {
                        await LoadNextPageAsync();
                    }
                }

                if (DeviceInfo.Platform == DevicePlatform.iOS
                    && VisibleStopItems.Count == 0
                    && e.ScrollY < -10)
                {
                    await scrollView.ScrollToAsync(0, 0, false);
                }
            }
            catch (Exception ex)
            {

            }
        }
    }

}
